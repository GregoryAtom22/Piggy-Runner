using NUnit.Framework;

namespace UnityEditor.Experimental.U2D.PSDImporter.Tests
{
    internal class Placeholder
    {
        [Test]
        public void PlaceHolderTest()
        {
            // Use the Assert class to test conditions.
            Assert.Pass("This is a placeholder to ensure we have at least one test.");
        }
    }
}
